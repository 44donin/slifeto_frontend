
import './App.css';
import Home from "./components/home"
import Confirmation from "./components/confirmation"
import Final from "./components/final"
import {BrowserRouter as Router, Route} from "react-router-dom"
import Admin from "./components/admin"
function App() {
  return (
    <div >
      
     
      <Router>
        <Route exact path="/" component={Home} />
        <Route exact path="/confirmation" component={Confirmation} />
        <Route exact path="/final" component={Final} />
        <Route exact path="/admin" component={Admin} />
      </Router>
    </div>
  );
}

export default App;
