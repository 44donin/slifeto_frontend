import React from 'react'
import Button from "@material-ui/core/Button"
import { Link} from "react-router-dom"
import { GridList, GridListTile } from '@material-ui/core'
import '../csscomponents/bus.css'
import Popup from 'reactjs-popup'
export default function Bus(props) {
    console.log(props.details)
    var BusAc = "no"
    if(props.details.routeBusAC === true){
        BusAc = "yes"
    }
    
    return (
        <div className="Bus">
            <span>InitialOrigin:</span> {props.details.routeVia[0]} <span>
            <Popup 
            trigger={<span className="ViaButton">  via    </span>} position="bottom center">
                
                <GridList cellHeight={20} cols={1} className="Grid-List-Via">
                    {props.details.routeVia.map((item)=>(
                        <GridListTile>
                                <div >{item}</div>
                        </GridListTile>
                    ))}

                </GridList>
            </Popup>
              FinalDestination:</span> {props.details.routeVia[props.details.routeVia.length -1]} <span>
                Bus:</span> {props.details.routeBusName}   <span>
                    Ac:</span>{BusAc}  <span>AvilableSeats:</span>{props.details.seatsavilable} 
                    <span>Time:</span>{props.details.time}
                    <Link className="LinkToFinal" to={{pathname : "/final",state:{props : props.details}}} ><Button className="BookTicketButton" variant="text" color="primary">book ticket</Button></Link> 
        </div>
    )
}
