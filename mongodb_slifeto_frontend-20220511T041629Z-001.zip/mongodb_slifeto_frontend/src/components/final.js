import React, { useState } from 'react'
import Button from "@material-ui/core/Button"
import { Link} from "react-router-dom"
import axios from 'axios'
import "../csscomponents/final.css"
export default function Final(props) {
        
        const [name,setName] = useState('')
        const [userage,setAge] = useState('')
        const [usergender, setGender] = useState('')
        const [usermobile, setMobile] = useState("")
        const [ticket,setTicket] = useState()
        
        const [isLoading, setLoading] = useState(true)
        const ticketInput = {
            from : props.location.state.props.from,
            to : props.location.state.props.to,
            route_name : props.location.state.props.routeName,
            route_time : props.location.state.props.time,
            date : props.location.state.props.routeDateOfJourney,
            bus_name : props.location.state.props.routeBusName,
            username : name,
            age : userage,
            gender : usergender,
            mobile : usermobile
        }
        
        //geting ticket details
        let GetTicket = e =>{
            axios.post('http://localhost:5000/booking',ticketInput).then(res=>{
                  
                setTicket(res.data)
                setLoading(false)
                }).catch(err=>{console.log("error while fetching data")})
        }
       
        if(isLoading === true){
            
            
            return (
                <div className="UserDetails">
                <span>Name:</span>
                <input type="text" onChange={(e)=>setName(e.target.value)}/><br/><br/>   
                <span>Age:</span>
                <input type="text" onChange={(e)=>setAge(e.target.value)}/><br/><br/>  
                <span>Mobile</span>
                <input type="text" onChange={(e)=>setMobile(e.target.value)}/><br/><br/>   
                <span>Gender</span>
                <span onChange={(e)=>setGender(e.target.value)}>
                    <input type="radio" value="Male" name="gender" /> Male
                    <input type="radio" value="Female" name="gender" /> Female
                    <input type="radio" value="Other" name="gender" /> Other
                </span><br/><br/> 
                <Button variant="contained" color="primary" onClick={GetTicket}>Get my ticket</Button> <br/><br/><br/>  <br/><br/><br/> 
                </div>
            )
        }else{
            var ac = "no"
            if(ticket.bus_ac === true){
                ac = "yes"
            }
            return (
                <div className="TicketDetails">
                    <span>Date:    </span>{ticket.date}<br/>
                    <span>Time:    </span>{ticket.route_time}<br/>
                    <span>Name:    </span>{ticket.passenger_name}<br/>
                    <span>Mobile:    </span>{ticket.passenger_mobile}<br/>
                    <span>Age:    </span>{ticket.passenger_age}<br/>
                    <span>SeatNumber:    </span>{ticket.passenger_seatNumber}<br/>
                    <span>BusNumber:    </span>{ticket.bus_name}<br/>
                    <span>Ac:    </span>{ac}<br/>
                    <span>driverName:    </span>{ticket.driver_name}<br/>
                    <span>driverPhoneNumber:    </span>{ticket.driver_number}<br/><br/>
                    <Link to="/" ><Button variant="contained" color="primary">Return to home</Button></Link>
                </div> 
                
            )
        }
        
        
}
