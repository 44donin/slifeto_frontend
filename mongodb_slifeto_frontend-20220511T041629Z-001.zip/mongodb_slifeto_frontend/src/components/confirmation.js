import React from 'react'
import Button from "@material-ui/core/Button"
import { Link} from "react-router-dom"
import axios from 'axios'
import {useState, useEffect} from 'react'
import Bus from "./bus"
import '../csscomponents/confirmation.css'
export default function Confirmation(props) {
 
    
    
    const [routes,setRoutes] = useState([])
    const input = {
        from : props.location.state.from_location,
        to : props.location.state.to_location,
        date : props.location.state.date_of_travel
    }
    
    useEffect(()=>{
        const fetchData = async () => {
            const result = await axios.post('http://localhost:5000/routes',input).then(res=>{
                   
            return res.data
            }).catch(err=>{console.log("error while fetching data")})
            setRoutes(result)
        }
        fetchData()
    })
    
        
    
    
    var list = routes.map((d)=> <Bus  details={d}/>)
    
    
  
    
    
    return (
       
        <div className="Confirmation">
             <h3>confirmation</h3>
             
             <h4>From:   {props.location.state.from_location}<br/> To:     {props.location.state.to_location}<br/> on:     {props.location.state.date_of_travel}</h4>
             {list} <br/>
             <Link className="LinkToFinal" to={{pathname:"/final",state:{name:"sai"}}} ><Button variant="contained" color="primary">go to final</Button></Link>
         </div>
     )

 
    
}
