import React,{useState} from 'react'
import { Link} from "react-router-dom"
import Button from "@material-ui/core/Button"
import Calender from 'react-calendar'
import 'react-calendar/dist/Calendar.css'
import '../csscomponents/home.css'



export default function Home() {
    const [from,setFrom] = useState('selam')
    const [to,setTo] = useState("kakinada")
    const [date,setDate] = useState(new Date())
    
    
    
    return (
        <div className="Home">
            <h3>Home</h3>
            <span>From:</span> 
            
            <input type="text" onChange={(e)=>setFrom(e.target.value)}/><br/><br/>
            <span>To:</span>
            <input type="text" onChange={(e)=> setTo(e.target.value)}/><br/><br/>
            
            <center><Calender  onChange={setDate} value={date} /></center><br/><br/>
            

            
            <Link className="LinkToConfirmation" to={{pathname : "/confirmation",state:{to_location:to,from_location:from,date_of_travel:date.toLocaleDateString()}}} ><Button variant="contained" color="primary">find the buses</Button></Link><br/><br/>

            <Link className="LinkToAdmin" to="./admin"><Button variant="outlined" color="secondary">I am admin</Button></Link>
        </div>
    )
}
