import React from 'react';
import "../csscomponents/admin.css"
import Button from "@material-ui/core/Button"

function Admin(props) {
    return (
        <div className="Admin">
            <span>  AddnewBus:</span><br></br>
            <span>  BusName:  </span><input type="text" />
            <span>  BusNumber: </span><input type="text" />
            <span>  BusCapacity:   </span><input type="text" />
            <span>  AC: </span>
            <span >
                    <input type="radio" value={true} name="ac" /> yes
                    <input type="radio" value={false} name="ac" /> No  
            </span>
            <Button variant="text" color="primary">Add bus</Button><br/><br/>


            <span>  AddnewDriver:</span><br></br>
            <span>  DriverName:  </span><input type="text" />
            <span>  DriverMobileNumber: </span><input type="text" />
            <Button variant="text" color="primary">Add Driver</Button><br/><br/>


            <span>  UpdateDriverDetails:</span><br></br>
            <span>  DriverName:  </span><input type="text" /><br/>
            <span>Enter the new Details:</span>   <input type="checkbox" name="verifythebus"/>verify the bus name<br/>
            <span>                  DriverMobileNumber: </span><input type="text" />
            <Button variant="text" color="primary">Add Driver</Button><br/><br/>
            
        </div>
    );
}

export default Admin;